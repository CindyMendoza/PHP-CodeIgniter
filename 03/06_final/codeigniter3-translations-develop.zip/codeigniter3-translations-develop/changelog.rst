##########
Change Log
##########

Version 3.0.x
=============

Version 3.0.3
=============

Release Date: Oct 31, 2015

- No changes. Updated version # to sync with framework.

Version 3.0.2
=============

Release Date: Oct 8, 2015

-   Enhancements

    -   MY_Lang (optional) can provide automatic translation fallbacks.

-   Updated Translations

    -   arabic
    -   german
    -   hindi
    -   persian
    -   portuguese-brazilian
    -   romanian
    -   simplified-chinese
    -   thai
    -   vietnamese

-   New Translations

    -   latvian
    -   slovak 

Version 3.0.0
=============

Release Date: March 30, 2015

Initial "official" release, with settings consistent with CodeIgniter 3.0.0

